package com.usjt.tcc.model.entity;

public enum PerfilInvestidor {
	Conservador, Diversificado, Agressivo
}
