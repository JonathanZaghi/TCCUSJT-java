# TCCUSJT
Investimento

#Rotas Api

GET /api/transacoes - obter todas as transações.

GET /api/transacao/{id} - obter uma transação de acordo com o id passado na url.

GET /api/transacao/prever/{id}&{data} - prever valor da transação em uma data.

DELETE /api/transacao - deletar uma transação.

POST /api/transacao - inserir uma transação.

PUT /api/transacao - atualizar uma transação.